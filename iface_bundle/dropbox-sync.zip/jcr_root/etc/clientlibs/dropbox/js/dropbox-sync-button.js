(function(window, document, Granite, $) {
    var DROPBOX_ACTIVATOR = ".cq-siteadmin-admin-actions-dropbox",
    	options = {
        success: function(files) {
			var filesList = [],
				currentUrl = window.location.href,
				rootFolder = '/content/dam/',
                url = 'http://localhost:4502/bin/repository/storeDropboxResource',
 				rootFolderNameLength = rootFolder.length,
                targetFolder;

            files.forEach(function(file){
				filesList.push(file.link);
            });

            targetFolder = currentUrl.substring(currentUrl.indexOf(rootFolder) + rootFolderNameLength, currentUrl.length) + '/';
            console.log(targetFolder);

            $.ajax({
                url: url,
                data: {files_list : filesList, targetFolder : targetFolder}
            })
        },
        linkType: 'direct',
        multiselect: true,
        extensions: ['images', 'audio', 'video', 'documents', 'text'],
	};

    $(document).on('click', DROPBOX_ACTIVATOR, function(e) {
		Dropbox.choose(options);
    });
})(window, document, Granite, Granite.$);